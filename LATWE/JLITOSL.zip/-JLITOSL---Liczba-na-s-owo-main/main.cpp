#include <iostream>

using namespace std;

int main() 
{
	string jednosci[10] =	{" ",
						"jeden",
						"dwa",
						"trzy",
						"cztery",
						"piec",
						"szesc",
						"siedem",
						"osiem",
						"dziewiec"
				};
	string dziesiatki[10] = { " ",
						"dziesiec"
						"dwadziescia"
						"trzydziesci"
						"czterdziesci"
						"piecdziesiat"
						"szczescdziesiat"
						"siedemdziesiat"
						"osiemdziesiat"
						"dziewiedziat"
				};
	string sietki[10] = { " ",
						"sto"
						"dwiescie"
						"trzysta"
						"czterysta"
						"piecset"
						"szczescset"
						"siedemset"
						"osiemset"
						"dziewiecset"
				};
	string nastki[10] = {" ",
						"dziesiec"
						"jedenascie"
						"dwanascie"
						"trzynascie"
						"czternascie"
						"pietnascie"	
						"szesnascie"	
						"siedemnascie"
						"osiemnascie"
						"dziewietnascie"
				};
	string setki[10] = {" ",
						"sto"
						"dwiescie"
						"trzysta"
						"czterysta"
						"piecset"
						"szescset"
						"siedemset"
						"osiemset"
						"dzewiecset"
				};
	string skroty[4] = {" ",
						"tys."
						"mln."
						"mld."
						"bln."
				};
}
