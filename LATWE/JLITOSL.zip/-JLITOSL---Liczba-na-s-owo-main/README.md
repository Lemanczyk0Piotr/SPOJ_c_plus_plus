# -JLITOSL---Liczba-na-s-owo


https://pl.spoj.com/problems/JLITOSL/


Jaś zaczął pracować w dziale firmy odpowiedzialnym za finanse. Do jego codziennych obowiązków należy wypełnianie przelewów pocztowych za różnego rodzaju płatności. Po kilku dniach zaczął odczuwać zniechęcenie, gdy po raz setny musiał na przelewie wypisywać słownie kwotę.

Pomoż Jasiowi i napisz program, który będzie zamieniał liczbę na jej zapis słowny.

Wejście
W pierwszym wierszu podana jest liczba testów t do wykonania (liczba naturalna z przedziału 1..1000). W następnych t wierszach liczba naturalna z przedziału 1..1012.

Wyjście
Na wyjściu powinny być wyświetlane w osobnych wierszach odpowiedniki liczb naturalnych podanych na wejściu w zapisie słownym (w wyrazach nie używamy polskich znaków). W zapisie należy użyć następujących skrótów: tys. - tysiąc, mln. - milion, mld. - miliard, bln. - bilion.

Przykład
Wejście:
5
1
12
345
1459
123456789

Wyjście:
jeden
dwanascie
trzysta czterdziesci piec
jeden tys. czterysta piecdziesiat dziewiec
sto dwadziescia trzy mln. czterysta piecdziesiat szesc tys. siedemset osiemdziesiat dziewiec
