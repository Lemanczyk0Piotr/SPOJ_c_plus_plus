# PP0602B---Tabelki-liczb

https://pl.spoj.com/problems/PP0602B/

Przesuń elementy w tablicy w taki sposób, jak pokazano w przykładzie (obróć ramkę w lewo).

Wejście
Najpierw t - liczba testów. Następnie dla każdego testu dwie liczby l i k - odpowiednio liczba wierszy i kolumn w tablicy - następnie l wierszy po k liczb całkowitych, 3 <= l, k <= 100.

Wyjście
Dla każdego testu l wierszy po k liczb w zmienionym porządku.

Przykład 1
Wejście:
1
3 3
1 2 3
4 5 6 
7 8 9 

Wyjście:
2 3 6 
1 5 9
4 7 8 
Przykład 2
Wejście:
1
3 5
1 2 3 4 5 
6 7 8 9 0
1 2 3 4 5

Wyjście:
2 3 4 5 0
1 7 8 9 5
6 1 2 3 4 
